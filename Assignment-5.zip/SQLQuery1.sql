Use Assignment

--- Creating State Table ---

CREATE TABLE [State]
(
 [SPK] Int IDENTITY ,
 [StateAbbreviation] Nvarchar(10) NOT NULL,
 [StateName] Nvarchar(50) ,
 [StateFIPS] Nvarchar(50) 
)
go
ALTER TABLE [State] ADD CONSTRAINT [Key1] PRIMARY KEY ([StateAbbreviation])
go

-- Creating County Table ---

CREATE TABLE [County]
(
 [SPK] Int IDENTITY ,
 [CountyName] Nvarchar(50) ,
 [FIPS] Nvarchar(50) ,
 [StateAbbreviation] Nvarchar(10) NOT NULL
)
go
ALTER TABLE [County] ADD CONSTRAINT [Key2] PRIMARY KEY ([StateAbbreviation])
go

-- Creating Zip Table ---

CREATE TABLE [Zip]
(
 [SPK] Int IDENTITY ,
 [Zip] Nvarchar(50) ,
 [town] Nvarchar(50) ,
 [StateAbbreviation] Nvarchar(10) NOT NULL
)
go
ALTER TABLE [Zip] ADD CONSTRAINT [Key3] PRIMARY KEY ([StateAbbreviation])
go

-- Creating Foreign Keys ---
 
ALTER TABLE [County] ADD CONSTRAINT [Relationship1] FOREIGN KEY ([StateAbbreviation]) REFERENCES [State] ([StateAbbreviation]) ON UPDATE NO ACTION ON DELETE NO ACTION
go
ALTER TABLE [Zip] ADD CONSTRAINT [Relationship2] FOREIGN KEY ([StateAbbreviation]) REFERENCES [State] ([StateAbbreviation]) ON UPDATE NO ACTION ON DELETE NO ACTION
go



--- SQL script for validating results in SSIS package --


select* from MedicareZipExcel_Staging
where [Overall Claims] =18632

truncate table MEdicareZipExcel_Staging

select * from MedicareCountryexcelStaging
where [Overall Claims] =212377

truncate table MedicareCountryexcelStaging

-- Creating Audit log table for County ---

Create table dbo.AuditingFilescounty
(
Id int identity(1,1),
FileName VARCHAR(100),
RecordCnt_county Int,
Loadedon Datetime default getdate()
)

Delete table dbo.AuditingFilescounty

Truncate table dbo.AuditingFilescounty

insert into dbo.AuditingFilescounty (FileName, RecordCnt_county) values (?,?)

select * from AuditingFilescounty


-- creating Audit log table for Zip --

select * from AuditingFileszip

Create table dbo.AuditingFileszip
(
Id int identity(1,1),
FileName VARCHAR(100),
RecordCnt_zip Int,
Loadedon DateTime default getdate()
)

insert into dbo.AuditingFileszip (FileName,RecordCnt_zip) values (?,?)

Truncate table AuditingFileszip

-- validation Task --

select * from dbo.Medicarecountyaggregated

truncate table dbo.Medicarecountyaggregated

select * from dbo.Medicarezipaggregated

truncate table dbo.Medicarezipaggregated


--validating after lookup --
Truncate Table dbo.[medicarecountymatch]

Truncate Table dbo.[medicare zip count]

select * from dbo.[medicarecountymatch]

select * from dbo.[medicarecontynonmatch]

select * from dbo.[medicare zip count]

select * from dbo.[medicare zip non match]